# tailify

React Tailwind Component Library

# Configuration

Add "./node_modules/@nayeshdaggula/tailify/dist/**/*.{js,ts,jsx,tsx}" this to your "tailwind.config.js" file in the content section
